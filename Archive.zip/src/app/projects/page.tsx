import React from "react";

const Projects = () => {
  return <div>Hello, Projects!</div>;
};

export default Projects;
